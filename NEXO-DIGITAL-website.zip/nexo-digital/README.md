# NEXO DIGITAL: Corporate Website Template

A premium, responsive website template for a technology and AI solutions agency.
Pure HTML, CSS and JavaScript. No build tools, no frameworks, no API keys.

- Dark navy design with violet and electric-blue gradients and glass-style cards
- Persian (RTL) and English (LTR) with a one-tap language switch
- Editable brand name, logo, colors and contact details from one file
- WhatsApp button (hidden until you add a number)
- Ready for GitHub Pages

## Folder structure

```
nexo-digital/
├── index.html
├── README.md
├── css/
│   └── style.css
└── js/
    ├── config.js    <- brand, colors, contact details
    ├── i18n.js      <- all Persian and English text
    └── main.js      <- behavior (do not need to edit)
```

## Customize for a client

1. Open `js/config.js` and change the brand name, logo text, colors, email, phone, address and social links.
2. To use a logo image, put it in a new `img/` folder and set `logoImage: "img/logo.png"`.
3. To enable the WhatsApp button, set `whatsapp` to the number with country code, digits only (for example `441234567890`).
4. Open `js/i18n.js` to change any text in Persian or English.
5. Replace the sample projects and sample testimonials with real ones. They are marked "Sample" on purpose, so do not publish them as real client feedback.

## Contact form

The form opens the visitor's email app with the message filled in. It does not store or send anything by itself.
If you need a form that sends messages directly, connect a form service of your choice and change the `submit` handler in `js/main.js`.

## Publish on GitHub Pages (from a phone)

1. Create a free account at github.com and tap **New repository**. Name it, keep it **Public**, and create it.
2. Unzip this project on your phone (the Files app can do this).
3. In the repository, tap **Add file > Upload files**, then upload `index.html`, `README.md`, and the `css` and `js` folders. If your phone cannot upload folders, create each file with **Add file > Create new file**, typing the path as `css/style.css`, `js/config.js`, and so on, then paste the contents.
4. Tap **Commit changes**.
5. Go to **Settings > Pages**. Under **Branch**, choose `main` and `/ (root)`, then **Save**.
6. After a minute or two your site appears at `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## Notes

- Fonts (Vazirmatn and Space Grotesk) load from Google Fonts. If they cannot load, the site falls back to system fonts.
- Keep `index.html` in the root and keep the `css/` and `js/` folder names exactly as they are, or update the paths at the bottom and top of `index.html`.
- The script order in `index.html` matters: `config.js`, then `i18n.js`, then `main.js`.
